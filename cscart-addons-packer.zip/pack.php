<?php

$dir_from = 'D:/dnwr/home/test1.ru/cscart/';
$dir_to = getcwd().'/';
$addon_name = basename($dir_to);

$sub_dirs = array(
	'app/addons/'.$addon_name,
	'design/backend/templates/addons/'.$addon_name,
	'js/addons/'.$addon_name,
);

$scan_dir_masks = array(
	'design/themes/*/*/templates/addons/'.$addon_name,
	'design/themes/*/templates/addons/'.$addon_name,
	'design/themes/*/css/addons/'.$addon_name,
	'var/themes_repository/*/templates/addons/'.$addon_name,
	'design/themes/*/media/*/addons/'.$addon_name,
);

$scan_file_masks = array(
	'var/langs/*/addons/'.$addon_name.'.po',
);

foreach($scan_dir_masks as $scan_dir_mask)
foreach(glob($dir_from.$scan_dir_mask, GLOB_ONLYDIR) as $dir){
	$sub_dirs[] = preg_replace('#^'.preg_quote($dir_from, '#').'#', '', $dir);
}

function ex($cmd){
	echo "EXEC $cmd\r\n";
	passthru($cmd);
}

$zip = new ZipArchive();
$xml_filename = $dir_from.'app/addons/'.$addon_name.'/addon.xml';
if(file_exists($xml_filename)){
	$o = simplexml_load_file($xml_filename);
	$version = (string) $o->version;
	$filename = $dir_to.$addon_name.'-'.$version.'.zip';
}else{
	$filename = $dir_to.$addon_name.'.zip';
}
var_dump(compact('filename'));

if ($zip->open($filename, ZipArchive::CREATE) !== true) {
    exit("���������� ������� <$filename>\n");
}


echo "numfiles: " . $zip->numFiles . "\n";
echo "status:" . $zip->status . "\n";

$cleaned_dirs = array();

foreach($sub_dirs as $sub_dir){
	
	if(empty($cleaned_dirs[$sub_dir])){
		ex('rm -rf '.escapeshellarg($dir_to.$sub_dir));
		@mkdir(dirname($dir_to.$sub_dir), 0777, true);
		$cleaned_dirs[$sub_dir] = true;
	}
	
	if(!file_exists($dir_from.$sub_dir)){
		continue;
	}
	
	ex('cp -rf '.escapeshellarg($dir_from.$sub_dir).' '.escapeshellarg($dir_to.$sub_dir));
	
	$files = array_filter(array_merge(
		glob($dir_to.$sub_dir.'/*'),
		glob($dir_to.$sub_dir.'/*/*'),
		glob($dir_to.$sub_dir.'/*/*/*'),
		glob($dir_to.$sub_dir.'/*/*/*/*')
	), 'is_file');
	
	foreach($files as $file){
		
		$local_file = preg_replace('#^'.preg_quote($dir_to,'#').'#', '', $file);
		
		echo "ADD $file\r\n\tAS $local_file\r\n";
		
		$zip->addFile(
			$file,
			$local_file
		);
		
	}
	
}



foreach($scan_file_masks as $scan_file_mask)
foreach(glob($dir_from.$scan_file_mask) as $file){
	$sub_file = preg_replace('#^'.preg_quote($dir_from, '#').'#', '', $file);
	$sub_dir = dirname($sub_file);
	
	if(empty($cleaned_dirs[$sub_dir])){
		ex('rm -rf '.escapeshellarg($dir_to.$sub_dir));
		@mkdir($dir_to.$sub_dir, 0777, true);
		$cleaned_dirs[$sub_dir] = true;
	}
	
	ex('cp -rf '.escapeshellarg($dir_from.$sub_file).' '.escapeshellarg($dir_to.$sub_file));
	
	echo "ADD $file\r\n\tAS $sub_file\r\n";
	
	$zip->addFile(
		$file,
		$sub_file
	);
	
}

$zip->close();